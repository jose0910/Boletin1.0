"""Crea una funcion que comprobe si un contrasinal pasado por parámetro
ten polo menos unha letra mayuscula A función retornará un valor booleano indicando si ten letra mayuscula ou non.
"""
def comprobarContrasinal():
    contrasinal= input("Introduce un contrasinal: ")

    si= True
    no= False
    for x in contrasinal:

        print(no)
    else:
        print(si)


comprobarContrasinal()